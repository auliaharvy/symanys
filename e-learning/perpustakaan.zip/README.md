# ASIS - Aplikasi Sistem Sekolah
Merupakan aplikasi untuk dunia Pendidikan di Indonesia. ASIS SATU UNTUK SEMUA
Fitur didalam asis
1. Asis Panel
2. Asis Akademik
3. Asis Kesiswaan
4. Asis Keuangan
5. Asis Perpustakaan
6. Asis Alumni
7. Asis Buku Tamu
8. Asis Arsip Digital
9. Asis Kelulusan
10. Asis PPDB
11. Asis E-Learning (dalam pengembangan)
12. Asis CBT (dalam pengembangan)

*ASIS akan selalu kami update dan kembangkan (saran dan masukannya sangat kami terima).
*Mohon tidak memperjualbelikan aplikasi asis dan menghilangakn copyright asis
*Jika terdapat menjual belikan aplikasi asis di luar dari pemilik (MAKA HAK LICENCE Akan kami hapus & tidak akan mendapatkan update terbaru dari kami)

*Jika Terdapat ERROR atau BUG dalam sistem silahkan langsung hubungi tim suport kami (082289663344).
*Segala Sesuatu yang berhungan dengan asis silahkan jangan sungkan untuk bertanya.

*Untuk Password RAR (asisberjaya*) Tanpa BukaTutup Kurung
Untuk Semua Pengguna ASIS
Silahkan Gabung di Grub Facebook
https://www.facebook.com/groups/181558652941070/

Tim Support ASIS
AlmairaStudio
email 	: almairastudio@gmail.com
Telp 	: 0822 8966 3344
Web ASIS http://asis.my.id
SEMOGA BERMANFAAT
